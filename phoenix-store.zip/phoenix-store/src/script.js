let currentToy = 'none';
let selectedColor = 'none';
let selectedAccessories = [];
let price = 12;

// Función para seleccionar el peluche
function selectToy(toy) {
    currentToy = toy;
    updateToyImage();
}

// Función para cambiar el color de la piel
function changeSkin(skin) {
    currentSkin = skin;
    updateToyImage();
}

// Función para cambiar el color del peluche
function changeColor(color) {
    currentColor = color;
    price = 18; // Cambiar el precio si hay personalización
    updateToyImage();
}

// Función para añadir accesorios
function addAccessory(accessory) {
    currentAccessory = accessory;
    price = 18; // Cambiar el precio si hay personalización
    updateToyImage();
}

// Función para actualizar la imagen del peluche con todas las opciones seleccionadas
function updateToyImage() {
    let baseUrl = "https://via.placeholder.com/300x400.png?text=";

    // Definir la base de la imagen dependiendo del peluche
    let toyUrl = baseUrl + currentToy.charAt(0).toUpperCase() + currentToy.slice(1);
    
    // Añadir color de piel
    if (currentSkin !== 'default') {
        toyUrl += `+${currentSkin}`;
    }

    // Añadir color del peluche
    if (currentColor) {
        toyUrl += `+${currentColor}`;
    }

    // Añadir accesorios
    if (currentAccessory) {
        toyUrl += `+${currentAccessory}`;
    }

    // Actualizar el src de la imagen de previsualización
    document.getElementById('toy-image').src = toyUrl;
}

// Ejemplo de uso:
selectToy('santa');  // Cambia a Santa Claus
changeSkin('brown'); // Cambia a piel marrón
changeColor('red');  // Cambia el color a rojo
addAccessory('hat'); // Añade un sombrero
function changeSkin(skin) {
    let skinColor = '';
    
    switch(skin) {
        case 'default':
            skinColor = '#f5c6a5'; // Color claro de piel
            break;
        case 'brown':
            skinColor = '#8d5524'; // Marrón
            break;
        case 'dark':
            skinColor = '#4b3026'; // Oscuro
            break;
        default:
            skinColor = '#f5c6a5'; // Piel clara por defecto
    }
    
    console.log('Skin selected:', skin);
    document.getElementById('toy-image').style.filter = `hue-rotate(${getSkinHue(skin)})`;
}

// Función para obtener el valor de hue-rotate según el color de piel
function getSkinHue(skin) {
    switch (skin) {
        case 'brown': return 40;
        case 'dark': return 80;
        default: return 0;
    }
}

function changeColor(color) {
    selectedColor = color; // Guardar el color seleccionado
    document.getElementById('toy-image').style.filter = `hue-rotate(${getHue(color)}deg)`;
    price = 18; // Cambiar el precio si hay personalización
    updatePrice();
}

function addAccessory(accessory) {
    if (!selectedAccessories.includes(accessory)) {
        selectedAccessories.push(accessory); // Añadir accesorio si no está ya en la lista
    }
    price = 18; // Cambiar el precio si hay personalización
    updatePrice();
}

function updatePrice() {
    document.getElementById('price').textContent = `Precio: ${price} soles`;
}

function finalizeOrder() {
    document.getElementById('order-details').style.display = 'block';
}

function submitOrder() {
    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;
    const card = document.getElementById('card').value;

    if (name && address && card) {
        // Mostrar combinación en un mensaje
        const accessoriesText = selectedAccessories.length > 0 ? ` con ${selectedAccessories.join(', ')}` : '';
        const combinationMessage = `Tu combinación: ${currentToy.charAt(0).toUpperCase() + currentToy.slice(1)} en color ${selectedColor || 'sin color'}${accessoriesText}. Precio: ${price} soles. ¡Feliz Navidad!`;
        
        alert(`Pedido realizado exitosamente para ${name}.\n${combinationMessage}`);
        
        // Reiniciar valores
        resetOrder();
    } else {
        alert('Por favor, completa todos los campos.');
    }
}

function resetOrder() {
    currentToy = 'none';
    selectedColor = 'none';
    selectedAccessories = [];
    price = 12;
    updatePrice();
    document.getElementById('order-details').style.display = 'none';
    document.getElementById('toy-image').src = 'https://via.placeholder.com/300x400.png?text=Elige+un+Peluche'; // Resetear imagen
    document.getElementById('name').value = '';
    document.getElementById('address').value = '';
    document.getElementById('card').value = '';
}

function getHue(color) {
    switch (color) {
        case 'red': return 0;
        case 'green': return 120;
        case 'blue': return 240;
        default: return 0;
    }
}

// Efecto de copos de nieve
function createSnowflake() {
    const snowflake = document.createElement('div');
    snowflake.className = 'snowflake';
    snowflake.style.left = Math.random() * 100 + 'vw'; // Posición aleatoria horizontal
    snowflake.style.animationDuration = Math.random() * 3 + 2 + 's'; // Duración aleatoria de la caída
    document.body.appendChild(snowflake);
    setTimeout(() => {
        snowflake.remove();
    }, 5000); // Remover después de 5 segundos
}

// Efecto de luces navideñas
function createLights() {
    const light = document.createElement('div');
    light.className = 'light';
    light.style.left = Math.random() * 100 + 'vw'; // Posición aleatoria horizontal
    light.style.top = Math.random() * 100 + 'vh'; // Posición aleatoria vertical
    light.style.backgroundColor = getRandomColor(); // Color aleatorio
    light.style.width = Math.random() * 20 + 10 + 'px'; // Ancho aleatorio
    light.style.height = light.style.width; // Alto igual al ancho
    document.body.appendChild(light);
    setTimeout(() => {
        light.remove();
    }, 1000); // Remover después de 1 segundo
}

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

// Iniciar efectos de nieve y luces
setInterval(createSnowflake, 300); // Crear copo de nieve cada 300ms
setInterval(createLights, 500); // Crear luz cada 500ms